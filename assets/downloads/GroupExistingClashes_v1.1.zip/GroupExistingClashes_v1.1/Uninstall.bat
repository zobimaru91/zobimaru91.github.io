@echo off
setlocal
title Uninstall - Group Existing Clashes

net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

tasklist /fi "imagename eq Roamer.exe" | find /i "Roamer.exe" >nul
if not errorlevel 1 (
  echo Navisworks is running. Close ALL Navisworks windows, then run Uninstall.bat again.
  pause
  exit /b 1
)

for /d %%D in ("%ProgramFiles%\Autodesk\Navisworks Manage *") do (
  if exist "%%~fD\Plugins\GroupExistingClashes" (
    rmdir /s /q "%%~fD\Plugins\GroupExistingClashes"
    echo Removed from %%~nxD
  )
)
for /d %%D in ("%APPDATA%\Autodesk Navisworks Manage *") do (
  if exist "%%~fD\Plugins\GroupExistingClashes" rmdir /s /q "%%~fD\Plugins\GroupExistingClashes"
)
if exist "%APPDATA%\GroupExistingClashes" rmdir /s /q "%APPDATA%\GroupExistingClashes"

echo.
echo Group Existing Clashes has been removed.
pause
