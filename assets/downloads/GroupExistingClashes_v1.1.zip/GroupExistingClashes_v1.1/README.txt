GROUP EXISTING CLASHES  -  Navisworks Manage add-in  (v1.1)
===========================================================

WHAT IT DOES
------------
Taking over a model that already has clash results? This add-in "parks"
the clashes that exist today in one named group, so you only review NEW
clashes from now on.

For every clash test in the open file (including tests in folders) it puts
the clashes into ONE group per test, with the name and status you choose.


HOW IT WORKS  (3 steps)
------------
1. "Overwrite existing groups and statuses?"   (only asked if groups exist)
     YES  - all existing groups are removed and ALL clashes go into the
            new group.
     NO   - existing groups and their statuses stay exactly as they are.
            Only clashes that are not in a group go into the new group.
            (If a group with the same name already exists, they are
            added to it.)

2. Choose the group name (e.g. "Existing Conditions") and the status:
     New / Active / Reviewed / Approved / Resolved / Keep current status
   Your choice is remembered for next time.

3. A progress window shows how many clashes are done, the percentage,
   elapsed time and time left. Cancel stops and leaves the file unchanged.

The whole change is one undo step (Ctrl+Z).


REQUIREMENTS
------------
- Windows 10 or 11
- Autodesk Navisworks MANAGE (Clash Detective is not in Simulate/Freedom)
- Administrator rights to install
- Nothing else to install (no Visual Studio needed)


INSTALL  (about 1 minute)
-------
1. Close Navisworks (all versions).
2. Right-click the zip > Extract All > Extract.
3. Open the extracted folder and double-click  Install.bat
4. Click "Yes" when Windows asks for permission.
   (If you see "Windows protected your PC": More info > Run anyway.)
5. Wait for "Installed for ... version(s)", then press any key.

The installer finds every Navisworks Manage version on the PC and sets up
the add-in for each one automatically. Installing over an older version
replaces it.


HOW TO USE
----------
1. Open your NWF file. Make sure the clash tests have been run.
2. Save a backup copy (recommended).
3. Go to the  Add-ins  tab and click  Group Existing Clashes.
   (No Add-ins tab? Right-click the ribbon > Show Tabs > Add-ins.)
4. Answer the questions and wait for the progress window to finish.
5. Check the result in Clash Detective and save the file.


GOOD TO KNOW
------------
- After you load new NWC files and re-run the tests, anything that shows
  as "New" outside the group is a new clash to review.
- If you set Resolved clashes to another status and they still don't clash
  after a re-run, Navisworks sets them back to Resolved.
- After a re-run, Navisworks keeps a clash in the group only if it sees it
  as the same clash. If new NWCs give elements new IDs, some old clashes
  can come back as New.
- While the add-in works, Navisworks can't be clicked. That is on purpose.


INSTALLED A NEW NAVISWORKS VERSION?
-----------------------------------
Just run Install.bat again.


UNINSTALL
---------
Close Navisworks and double-click  Uninstall.bat


TROUBLESHOOTING
---------------
"Navisworks is running"   Close every Navisworks window, including other
                          versions, and run Install.bat again.
"No Navisworks Manage     Navisworks Manage must be installed in
 installation found"      C:\Program Files\Autodesk\
A version says FAILED     That version's API may be different. Send the
                          message shown in the window to the author.
No button in Navisworks   Right-click the ribbon > Show Tabs > Add-ins.


FILES
-----
Install.bat                      install for all Navisworks Manage versions
Uninstall.bat                    remove the add-in from all versions
README.txt                       this file
source\GroupExistingClashes.cs   full C# source code


VERSION HISTORY
---------------
1.1  Ask before overwriting existing groups; choose status; progress
     window with time left and Cancel.
1.0  First release.
