@echo off
setlocal EnableDelayedExpansion
title Install - Group Existing Clashes for Navisworks Manage

rem --- ask for admin rights (needed to write into Program Files) ---
net session >nul 2>&1
if errorlevel 1 (
  echo Asking for administrator permission...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
set "SRC=%~dp0source\GroupExistingClashes.cs"
set "ROOT=%ProgramFiles%\Autodesk"
set /a FOUND=0, OK=0, BAD=0

echo ============================================================
echo   Group Existing Clashes - installer
echo ============================================================
echo.

if not exist "%SRC%" (
  echo Source file not found: %SRC%
  echo Extract the WHOLE zip first ^(right-click ^> Extract All^), then run Install.bat.
  goto :fail
)
if not exist "%CSC%" (
  echo The .NET Framework 4 compiler was not found on this PC:
  echo   %CSC%
  goto :fail
)

tasklist /fi "imagename eq Roamer.exe" | find /i "Roamer.exe" >nul
if not errorlevel 1 (
  echo Navisworks is running. Close ALL Navisworks windows ^(every version^),
  echo then run Install.bat again.
  goto :fail
)

for /d %%D in ("%ROOT%\Navisworks Manage *") do (
  if exist "%%~fD\Autodesk.Navisworks.Api.dll" call :installOne "%%~fD" "%%~nxD"
)

echo.
echo ------------------------------------------------------------
if %FOUND%==0 (
  echo No Navisworks Manage installation was found in:
  echo   %ROOT%
  echo This add-in needs Navisworks MANAGE ^(Clash Detective^).
  echo Navisworks Simulate and Freedom are not supported.
  goto :fail
)
echo Installed for %OK% of %FOUND% Navisworks Manage version^(s^).
if not %BAD%==0 echo %BAD% version^(s^) failed - see the messages above.
echo.
echo Start Navisworks and open the Add-ins tab.
echo ^(No Add-ins tab? Right-click the ribbon ^> Show Tabs ^> Add-ins.^)
echo.
pause
exit /b 0

rem ------------------------------------------------------------
:installOne
set "NW=%~1"
set "NAME=%~2"
set /a FOUND+=1
echo [%NAME%]

set "CLASHDLL=%NW%\Autodesk.Navisworks.Clash.dll"
if not exist "%CLASHDLL%" set "CLASHDLL=%NW%\Plugins\Autodesk.Navisworks.Clash\Autodesk.Navisworks.Clash.dll"
if not exist "%CLASHDLL%" (
  echo    SKIPPED - Clash Detective files not found.
  set /a BAD+=1
  goto :eof
)

rem old per-user copy from earlier test builds
set "YEAR=%NAME:Navisworks Manage =%"
set "OLD=%APPDATA%\Autodesk Navisworks Manage %YEAR%\Plugins\GroupExistingClashes"
if exist "%OLD%" rmdir /s /q "%OLD%"

set "OUT=%NW%\Plugins\GroupExistingClashes"
if not exist "%OUT%" mkdir "%OUT%"

"%CSC%" /nologo /target:library /platform:x64 /optimize+ ^
  /out:"%OUT%\GroupExistingClashes.dll" ^
  /reference:"%NW%\Autodesk.Navisworks.Api.dll" ^
  /reference:"%CLASHDLL%" ^
  /reference:System.Windows.Forms.dll ^
  /reference:System.Drawing.dll ^
  "%SRC%" > "%TEMP%\gec_build.log" 2>&1
if errorlevel 1 (
  echo    FAILED - compiler output:
  type "%TEMP%\gec_build.log"
  if exist "%OUT%" rmdir /s /q "%OUT%"
  set /a BAD+=1
  goto :eof
)
echo    OK
set /a OK+=1
goto :eof

:fail
echo.
echo INSTALL FAILED - see the message above.
pause
exit /b 1
