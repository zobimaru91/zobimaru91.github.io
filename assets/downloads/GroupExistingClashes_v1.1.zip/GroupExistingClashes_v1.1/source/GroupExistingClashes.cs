// Navisworks Manage add-in: Group Existing Clashes (v1.1)
//
// For every clash test in the open file it puts clashes into ONE group with a
// name and status you choose.
//   - Pop-up 1: overwrite existing groups and statuses?  (Yes / No)
//       Yes = all groups are removed and ALL clashes go into the new group.
//       No  = existing groups (and their statuses) stay as they are; only
//             loose (ungrouped) clashes go into the new group.
//   - Pop-up 2: group name + status (or keep current status).
//   - Progress window with done / total, elapsed and time left. Cancel leaves
//     the file unchanged.
//
// Written in C# 5 so it builds with the compiler that ships with Windows.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autodesk.Navisworks.Api;
using Autodesk.Navisworks.Api.Clash;
using Autodesk.Navisworks.Api.Plugins;
using NavisApp = Autodesk.Navisworks.Api.Application;
using WinApp = System.Windows.Forms.Application;

[assembly: AssemblyTitle("Group Existing Clashes")]
[assembly: AssemblyDescription("Navisworks Manage add-in: groups clashes into one named group per test")]
[assembly: AssemblyProduct("Group Existing Clashes")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]

namespace GroupExistingClashes
{
    [Plugin("GroupExistingClashes", "FAJA",
        DisplayName = "Group Existing Clashes",
        ToolTip = "Put the clashes of every test into one named group, with the status you choose")]
    [AddInPlugin(AddInLocation.AddIn)]
    public class GroupExistingClashesPlugin : AddInPlugin
    {
        internal const string Title = "Group Existing Clashes";

        public override int Execute(params string[] parameters)
        {
            try
            {
                Run();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong:\n\n" + ex.ToString(),
                    Title, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return 0;
        }

        void Run()
        {
            Document doc = NavisApp.ActiveDocument;
            if (doc == null || doc.IsClear)
            {
                Info("No model is open.");
                return;
            }

            DocumentClash clash = doc.GetClash();
            if (clash == null)
            {
                Info("Clash Detective is not available in this file / product.");
                return;
            }
            DocumentClashTests data = clash.TestsData;

            List<TestRef> refs = new List<TestRef>();
            CollectTests(data.Tests, null, refs);
            if (refs.Count == 0)
            {
                Info("There are no clash tests in this file.");
                return;
            }

            // ---- count what is in the file ----
            int groupCount = 0, groupedClashes = 0, looseClashes = 0;
            foreach (TestRef r in refs)
            {
                foreach (SavedItem item in r.Test.Children)
                {
                    ClashResultGroup g = item as ClashResultGroup;
                    if (g != null) { groupCount++; groupedClashes += ResultsIn(g).Count; continue; }
                    if (item is ClashResult) looseClashes++;
                }
            }
            int totalClashes = groupedClashes + looseClashes;
            if (totalClashes == 0)
            {
                Info("No clash results found in " + refs.Count + " test(s).\n\nRun the tests first, then try again.");
                return;
            }

            // ---- pop-up 1: overwrite? ----
            bool overwrite = true;
            if (groupCount > 0)
            {
                DialogResult answer = MessageBox.Show(
                    "This file has " + N(groupCount) + " existing group(s) holding " + N(groupedClashes)
                    + " clash(es), and " + N(looseClashes) + " clash(es) that are not in a group.\n\n"
                    + "Do you want to OVERWRITE the existing groups and their statuses?\n\n"
                    + "YES  -  delete all existing groups and put ALL " + N(totalClashes)
                    + " clashes into the new group.\n\n"
                    + "NO  -  keep existing groups and their statuses exactly as they are.\n"
                    + "           Only the " + N(looseClashes) + " clash(es) that are not in a group are grouped.",
                    Title, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                if (answer == DialogResult.Cancel) return;
                overwrite = (answer == DialogResult.Yes);

                if (!overwrite && looseClashes == 0)
                {
                    Info("All clashes are already in groups, so there is nothing to group.\n\nNothing was changed.");
                    return;
                }
            }
            int toProcess = overwrite ? totalClashes : looseClashes;

            // ---- pop-up 2: name + status ----
            Settings settings = Settings.Load();
            string summary = overwrite
                ? "All existing groups will be deleted.\n" + N(toProcess) + " clash(es) in " + N(refs.Count)
                  + " test(s) will go into one group per test."
                : "Existing groups stay as they are.\n" + N(toProcess) + " clash(es) that are not in a group"
                  + " will go into one group per test.";
            GroupOptions opt = OptionsForm.Ask(summary, settings.GroupName, settings.StatusIndex);
            if (opt == null) return;
            settings.GroupName = opt.GroupName;
            settings.StatusIndex = opt.StatusIndex;
            settings.Save();

            // ---- do the work, with progress ----
            int changedTests = 0, grouped = 0, mergedTests = 0;
            Stopwatch clock = Stopwatch.StartNew();
            ProgressForm progress = new ProgressForm();
            IntPtr mainWindow = Process.GetCurrentProcess().MainWindowHandle;
            if (mainWindow != IntPtr.Zero) EnableWindow(mainWindow, false); // block clicks in Navisworks while working
            try
            {
                progress.Show();

                // Step 1: build the new tests in memory. Nothing in the file changes yet,
                // so Cancel here leaves the file exactly as it was.
                progress.StartStep("Step 1 of 2: Preparing clashes", "Clashes", toProcess, true);
                List<ClashTest> newTests = new List<ClashTest>();
                int done = 0;
                for (int i = 0; i < refs.Count; i++)
                {
                    progress.SetCurrent("Test " + (i + 1) + " of " + refs.Count + ":  " + refs[i].Test.DisplayName);
                    bool merged;
                    ClashTest copy = BuildTest(refs[i].Test, opt, overwrite, progress, ref done, out merged);
                    if (progress.Cancelled)
                    {
                        progress.Close();
                        Info("Cancelled. Nothing was changed.");
                        return;
                    }
                    newTests.Add(copy);
                    if (copy != null) changedTests++;
                    if (merged) mergedTests++;
                }
                grouped = done;

                // Step 2: write the new tests into the file (one undo step).
                progress.StartStep("Step 2 of 2: Writing changes to the file (please wait)", "Tests", changedTests, false);
                using (Transaction tr = doc.BeginTransaction(Title))
                {
                    int written = 0;
                    for (int i = 0; i < refs.Count; i++)
                    {
                        if (newTests[i] == null) continue;
                        progress.SetCurrent("Test " + (i + 1) + " of " + refs.Count + ":  " + refs[i].Test.DisplayName);
                        if (refs[i].Folder == null)
                            data.TestsReplaceWithCopy(refs[i].Index, newTests[i]);              // top-level test
                        else
                            data.TestsReplaceWithCopy(refs[i].Folder, refs[i].Index, newTests[i]); // test in a folder
                        written++;
                        progress.Report(written, true);
                    }
                    tr.Commit();
                }
            }
            finally
            {
                if (mainWindow != IntPtr.Zero) EnableWindow(mainWindow, true);
                if (!progress.IsDisposed) progress.Close();
                progress.Dispose();
            }

            string msg = "Done in " + ProgressForm.Format(clock.Elapsed) + ".\n\n"
                + N(grouped) + " clash(es) in " + N(changedTests) + " test(s) were grouped into \""
                + opt.GroupName + "\".\n"
                + "Status: " + (opt.KeepStatus ? "kept as it was" : "set to " + opt.Status) + ".\n"
                + "Existing groups: " + (overwrite ? "deleted." : "kept as they were.");
            if (mergedTests > 0)
                msg += "\n\nIn " + N(mergedTests) + " test(s) a group called \"" + opt.GroupName
                    + "\" already existed, so the clashes were added to it.";
            msg += "\n\nSave the file to keep the changes (Ctrl+Z undoes it).";
            Info(msg);
        }

        // Returns a new copy of the test with the grouping applied, or null if nothing changes.
        static ClashTest BuildTest(ClashTest test, GroupOptions opt, bool overwrite,
            ProgressForm progress, ref int done, out bool merged)
        {
            merged = false;
            List<ClashResult> toGroup = new List<ClashResult>();
            List<ClashResultGroup> keptGroups = new List<ClashResultGroup>();

            foreach (SavedItem item in test.Children)
            {
                ClashResultGroup g = item as ClashResultGroup;
                if (g != null)
                {
                    if (overwrite) toGroup.AddRange(ResultsIn(g));
                    else keptGroups.Add(g);
                    continue;
                }
                ClashResult r = item as ClashResult;
                if (r != null) toGroup.Add(r);
            }
            if (toGroup.Count == 0) return null;

            ClashTest testCopy = (ClashTest)test.CreateCopy();
            testCopy.Children.Clear();

            // Keep existing groups (No-mode). If one already has the chosen name, add to it.
            ClashResultGroup target = null;
            List<ClashResultGroup> keptCopies = new List<ClashResultGroup>();
            foreach (ClashResultGroup g in keptGroups)
            {
                ClashResultGroup gc = (ClashResultGroup)g.CreateCopy();
                keptCopies.Add(gc);
                if (target == null && string.Equals(g.DisplayName, opt.GroupName, StringComparison.OrdinalIgnoreCase))
                    target = gc;
            }

            bool newGroup = (target == null);
            if (newGroup)
            {
                target = new ClashResultGroup();
                target.DisplayName = opt.GroupName;
                if (!opt.KeepStatus) target.Status = opt.Status;
            }
            else merged = true;

            foreach (ClashResult r in toGroup)
            {
                ClashResult copy = (ClashResult)r.CreateCopy();
                if (!opt.KeepStatus) copy.Status = opt.Status;
                target.Children.Add(copy);
                done++;
                progress.Report(done, false);
                if (progress.Cancelled) return null;
            }

            if (newGroup) testCopy.Children.Add(target);
            foreach (ClashResultGroup gc in keptCopies) testCopy.Children.Add(gc);
            return testCopy;
        }

        // ---------- helpers ----------

        class TestRef
        {
            public ClashTest Test;
            public GroupItem Folder;   // null = top level
            public int Index;
        }

        static void CollectTests(SavedItemCollection items, GroupItem folder, List<TestRef> into)
        {
            for (int i = 0; i < items.Count; i++)
            {
                SavedItem item = items[i];
                ClashTest test = item as ClashTest;
                if (test != null)
                {
                    TestRef r = new TestRef();
                    r.Test = test; r.Folder = folder; r.Index = i;
                    into.Add(r);
                    continue;
                }
                GroupItem sub = item as GroupItem;
                if (sub != null) CollectTests(sub.Children, sub, into);
            }
        }

        static List<ClashResult> ResultsIn(ClashResultGroup g)
        {
            List<ClashResult> list = new List<ClashResult>();
            foreach (SavedItem child in g.Children)
            {
                ClashResult r = child as ClashResult;
                if (r != null) list.Add(r);
            }
            return list;
        }

        static string N(int n) { return n.ToString("N0"); }

        static void Info(string text)
        {
            MessageBox.Show(text, Title, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        [DllImport("user32.dll")]
        static extern bool EnableWindow(IntPtr hWnd, bool enable);
    }

    // ---------- options chosen in pop-up 2 ----------

    class GroupOptions
    {
        public static readonly string[] StatusNames =
            { "New", "Active", "Reviewed", "Approved", "Resolved", "Keep current status" };
        static readonly ClashResultStatus[] Statuses =
            { ClashResultStatus.New, ClashResultStatus.Active, ClashResultStatus.Reviewed,
              ClashResultStatus.Approved, ClashResultStatus.Resolved };

        public string GroupName;
        public int StatusIndex;

        public bool KeepStatus { get { return StatusIndex >= Statuses.Length; } }
        public ClashResultStatus Status { get { return KeepStatus ? ClashResultStatus.New : Statuses[StatusIndex]; } }
    }

    class OptionsForm : Form
    {
        TextBox nameBox;
        ComboBox statusBox;

        public static GroupOptions Ask(string summary, string defaultName, int defaultStatus)
        {
            using (OptionsForm f = new OptionsForm(summary, defaultName, defaultStatus))
            {
                while (true)
                {
                    if (f.ShowDialog() != DialogResult.OK) return null;
                    string name = f.nameBox.Text.Trim();
                    if (name.Length == 0)
                    {
                        MessageBox.Show("Please type a group name.", GroupExistingClashesPlugin.Title,
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        continue;
                    }
                    GroupOptions o = new GroupOptions();
                    o.GroupName = name;
                    o.StatusIndex = f.statusBox.SelectedIndex;
                    return o;
                }
            }
        }

        OptionsForm(string summary, string defaultName, int defaultStatus)
        {
            Text = GroupExistingClashesPlugin.Title;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            MinimizeBox = false; MaximizeBox = false; ShowInTaskbar = false;
            ClientSize = new Size(440, 230);
            Font = new Font("Segoe UI", 9f);

            Label info = new Label();
            info.Text = summary;
            info.SetBounds(12, 10, 416, 48);

            Label l1 = new Label();
            l1.Text = "Group name:";
            l1.SetBounds(12, 66, 416, 18);

            nameBox = new TextBox();
            nameBox.Text = defaultName;
            nameBox.SetBounds(12, 86, 416, 24);

            Label l2 = new Label();
            l2.Text = "Set the status of these clashes to:";
            l2.SetBounds(12, 120, 416, 18);

            statusBox = new ComboBox();
            statusBox.DropDownStyle = ComboBoxStyle.DropDownList;
            statusBox.Items.AddRange(GroupOptions.StatusNames);
            statusBox.SelectedIndex = (defaultStatus >= 0 && defaultStatus < GroupOptions.StatusNames.Length) ? defaultStatus : 2;
            statusBox.SetBounds(12, 140, 200, 24);

            Button ok = new Button();
            ok.Text = "Group clashes";
            ok.SetBounds(222, 186, 110, 30);
            ok.DialogResult = DialogResult.OK;

            Button cancel = new Button();
            cancel.Text = "Cancel";
            cancel.SetBounds(338, 186, 90, 30);
            cancel.DialogResult = DialogResult.Cancel;

            Controls.AddRange(new Control[] { info, l1, nameBox, l2, statusBox, ok, cancel });
            AcceptButton = ok;
            CancelButton = cancel;
            Shown += delegate { nameBox.SelectAll(); nameBox.Focus(); };
        }
    }

    // ---------- progress window ----------

    class ProgressForm : Form
    {
        Label stepLabel, currentLabel, countLabel, timeLabel;
        ProgressBar bar;
        Button cancelButton;
        Stopwatch totalClock = Stopwatch.StartNew();
        Stopwatch stepClock = new Stopwatch();
        long lastRefresh = -1000;
        int stepTotal = 1, lastDone;
        string unit = "";

        public bool Cancelled;

        public ProgressForm()
        {
            Text = GroupExistingClashesPlugin.Title;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            ControlBox = false; ShowInTaskbar = false; TopMost = true;
            ClientSize = new Size(480, 190);
            Font = new Font("Segoe UI", 9f);

            stepLabel = new Label();    stepLabel.SetBounds(12, 10, 456, 20);
            stepLabel.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
            currentLabel = new Label(); currentLabel.SetBounds(12, 34, 456, 20);
            currentLabel.AutoEllipsis = true;
            bar = new ProgressBar();    bar.SetBounds(12, 60, 456, 22);
            bar.Minimum = 0; bar.Maximum = 1000; bar.Style = ProgressBarStyle.Continuous;
            countLabel = new Label();   countLabel.SetBounds(12, 90, 456, 20);
            timeLabel = new Label();    timeLabel.SetBounds(12, 112, 456, 20);

            cancelButton = new Button();
            cancelButton.Text = "Cancel";
            cancelButton.SetBounds(378, 148, 90, 30);
            cancelButton.Click += delegate
            {
                Cancelled = true;
                cancelButton.Enabled = false;
                stepLabel.Text = "Cancelling...";
            };

            Controls.AddRange(new Control[] { stepLabel, currentLabel, bar, countLabel, timeLabel, cancelButton });
        }

        public void StartStep(string text, string unitName, int total, bool canCancel)
        {
            stepLabel.Text = text;
            unit = unitName;
            stepTotal = Math.Max(total, 1);
            cancelButton.Enabled = canCancel && !Cancelled;
            stepClock.Reset(); stepClock.Start();
            Report(0, true);
        }

        public void SetCurrent(string text)
        {
            currentLabel.Text = text;
            Report(lastDone, true);
        }

        // Updates the window at most 10 times a second so it doesn't slow the work down.
        public void Report(int done, bool force)
        {
            lastDone = done;
            long now = totalClock.ElapsedMilliseconds;
            if (!force && now - lastRefresh < 100) return;
            lastRefresh = now;

            double frac = Math.Min(1.0, done / (double)stepTotal);
            bar.Value = (int)(frac * 1000);
            countLabel.Text = unit + ": " + done.ToString("N0") + " of " + stepTotal.ToString("N0")
                + "   (" + ((int)(frac * 100)).ToString() + "%)";

            string left = "calculating...";
            double secs = stepClock.Elapsed.TotalSeconds;
            if (done > 0 && secs > 1)
                left = "about " + Format(TimeSpan.FromSeconds(secs / done * (stepTotal - done)));
            timeLabel.Text = "Elapsed: " + Format(totalClock.Elapsed) + "        Time left for this step: " + left;

            WinApp.DoEvents();
        }

        public static string Format(TimeSpan t)
        {
            if (t.TotalHours >= 1) return string.Format("{0}h {1:00}m", (int)t.TotalHours, t.Minutes);
            if (t.TotalMinutes >= 1) return string.Format("{0}m {1:00}s", (int)t.TotalMinutes, t.Seconds);
            return string.Format("{0}s", t.Seconds);
        }
    }

    // ---------- remembers the last name and status ----------

    class Settings
    {
        const string DefaultGroupName = "Existing Conditions";
        public string GroupName = DefaultGroupName;
        public int StatusIndex = 2; // Reviewed

        static string FilePath
        {
            get
            {
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "GroupExistingClashes", "settings.txt");
            }
        }

        public static Settings Load()
        {
            Settings s = new Settings();
            try
            {
                if (File.Exists(FilePath))
                {
                    string[] lines = File.ReadAllLines(FilePath);
                    if (lines.Length > 0 && lines[0].Trim().Length > 0) s.GroupName = lines[0].Trim();
                    int idx;
                    if (lines.Length > 1 && int.TryParse(lines[1].Trim(), out idx)) s.StatusIndex = idx;
                }
                else
                {
                    // name saved by v1.0
                    string old = Path.Combine(Path.GetDirectoryName(FilePath), "lastname.txt");
                    if (File.Exists(old))
                    {
                        string n = File.ReadAllText(old).Trim();
                        if (n.Length > 0) s.GroupName = n;
                    }
                }
            }
            catch { }
            return s;
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                File.WriteAllLines(FilePath, new string[] { GroupName, StatusIndex.ToString() });
            }
            catch { }
        }
    }
}
