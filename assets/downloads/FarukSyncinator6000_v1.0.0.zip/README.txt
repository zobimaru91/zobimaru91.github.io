﻿==============================================================
  FARUK SYNCINATOR 6000   v1.0.0
  One-click Synchronize with Central + Relinquish All Mine for Revit
  Copyright (c) 2026 Faruk Ajanovic. All rights reserved.
  Free for use under TERMS_OF_USE.txt
==============================================================

ALWAYS BACK UP YOUR MODEL AND CHECK ALL RESULTS.
This tool is an aid only. It syncs your work to the central model, so make
sure your changes are correct before you click it.
Use of the tool is governed by TERMS_OF_USE.txt (installed next to this file).


WHAT IT DOES
------------
Adds a "Faruk Syncinator 6000" tab to the Revit ribbon with one big button.
One click does:
  1. Synchronize with Central (with your current sync settings), then
  2. Relinquish All Mine: hands back all borrowed elements, worksets,
     family/view worksets and project settings to central.
  3. Shows "Sync complete" when both are done.

The button only works in workshared project files (central or local
models). It is greyed out for non-workshared files and families.
If Revit reports a problem (for example central is not reachable, or an
element is owned by someone else), the error is shown and nothing more is done.


SUPPORTED VERSIONS
------------------
  Autodesk Revit 2023, 2024, 2026  (64-bit, Windows 10/11)
  Not in this release: Revit 2025.


INSTALL
-------
  1. Close Revit.
  2. Run FarukSyncinator6000_Setup_v1.0.0.exe. It asks for administrator
     rights, because it installs for all users of the PC.
  3. Read and accept the Terms of Use.
  4. Tick the Revit versions to install for. The versions found on your PC
     are ticked for you.
  5. If an older Syncinator is installed, Setup offers to remove it first, so
     Revit does not load it twice. Answer Yes.
  6. Finish. Start Revit.

  The first time Revit starts after installing, it may ask about loading an
  add-in from an unknown publisher ("Security - Unsigned Add-In"). Choose
  "Always Load".

  If Windows SmartScreen shows "Windows protected your PC":
  More info > Run anyway.

  The tool is installed to:
    C:\ProgramData\Autodesk\ApplicationPlugins\FarukSyncinator6000.bundle\
  This is Autodesk's standard plugin location.

  Upgrading: just run the newer setup. It replaces the old version, so you
  don't need to uninstall first.


WHERE TO FIND IT
----------------
  Revit ribbon > "Faruk Syncinator 6000" tab > "Faruk Syncinator 6000" button.
  Hover over it for a description. Press F1 on it to open the Terms of Use.


UNINSTALL
---------
  Windows Settings > Apps > Installed apps > Faruk Syncinator 6000 > Uninstall
  (or Start menu > Faruk Syncinator 6000 > Uninstall Faruk Syncinator 6000).
  Close Revit first. Your models are not touched.


TROUBLESHOOTING
---------------
  The tab or button is missing
    - Restart Revit after installing. Check that you ticked that Revit version
      during setup. To add a version, run the setup again.
    - If you chose "Do Not Load" in Revit's security prompt, run the setup
      again, start Revit and choose "Always Load".
  Revit says an add-in with the same ID is already loaded
    - An older copy is still installed. Run the setup again and answer Yes
      when it offers to remove the old version.
  The button is grey
    - The open file is not workshared, or a family is active.


TERMS, PRIVACY, CONTACT
-----------------------
  - Use is governed by TERMS_OF_USE.txt. Provided AS IS, without warranty.
  - The tool runs only on your PC and talks only to your own Revit central
    model. No internet, nothing is sent anywhere else.
  - Third-party notices: THIRD_PARTY_NOTICES.txt
  - Autodesk and Revit are trademarks of Autodesk, Inc. This tool is not
    affiliated with or endorsed by Autodesk.
  - Contact: Faruk Ajanovic - ajanovic.faruk@gmail.com
