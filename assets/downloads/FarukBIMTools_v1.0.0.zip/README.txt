﻿==============================================================
  FARUK BIM TOOLS   v1.0.0
  Free Navisworks tools for BIM coordination
  Copyright (c) 2026 Faruk Ajanovic. All rights reserved.
  Free for use under TERMS_OF_USE.txt
==============================================================

ALWAYS BACK UP YOUR MODEL AND CHECK ALL RESULTS.
These tools are an aid only. Save a copy of your NWF/NWD before you change
anything with them, and check every result, ID, status and report yourself.
Use of the tools is governed by TERMS_OF_USE.txt (installed next to this file).


WHAT'S INCLUDED
---------------
All three are Navisworks Manage add-ins.

1. Faruk ClashReport 6000inator                       (reads only)
   Exports Clash Detective results as an HTML report with a picture per
   clash, plus a CSV for Excel.
   - Shows the correct Revit Element ID of each item (the Revit INSTANCE,
     not the nested-family ID the standard Navisworks report shows), so
     Revit's Manage > Select by ID finds it.
   - Organised by clash test and clash group (group = whose scope).
     Clash name, status, distance, location, description, assigned to and
     comments are included.
   - Source file and selection-tree path for item 1 and item 2.
   - A pop-up lets you pick which clash tests and statuses to export.
   - A progress window with Cancel. For very big exports Navisworks can
     only make about 800-900 pictures per session. The tool then pauses
     safely and continues next time with the same file name.

2. Group Existing Clashes                              (CHANGES the file)
   For every clash test: removes all clash groups, puts every clash into one
   group with the name you type, and sets them to the status you pick
   (New / Active / Reviewed / Approved / Resolved). Useful for marking
   existing-condition clashes. Save the file afterwards to keep it.

3. Clash Status Export / Clash Status Import           (Import CHANGES the file)
   Carries clash statuses (Approved) from one file to another - for example
   from a client's NWD to your new NWF - by matching clashes on the pair of
   Revit Element IDs.
   - Export: open the source file > Clash Status Export > save a .tsv
   - Import: open your file (same models, same tests, tests RUN) >
     Clash Status Import > pick the .tsv. A log is written next to the .tsv.


SUPPORTED VERSIONS
------------------
  Autodesk Navisworks Manage 2023, 2025, 2026  (64-bit, Windows 10/11)
  Not supported: Navisworks Manage 2024 (not in this release), Navisworks
  Simulate and Freedom (they have no Clash Detective).
  Revit add-ins and Dynamo scripts: not in this release.


INSTALL
-------
  1. Close Navisworks.
  2. Run FarukBIMTools_Setup_v1.0.0.exe (it asks for administrator rights,
     because it installs for all users of the PC).
  3. Read and accept the Terms of Use.
  4. Tick the Navisworks versions to install for. The versions found on
     your PC are ticked for you.
  5. Finish. Start Navisworks.

  If Windows SmartScreen shows "Windows protected your PC":
  More info > Run anyway.

  The tools are installed to:
    C:\ProgramData\Autodesk\ApplicationPlugins\FarukBIMTools.bundle\
  This is Autodesk's standard plugin location. Navisworks loads them
  automatically.

  Upgrading: just run the newer setup. It replaces the old version, so
  you don't need to uninstall first.


WHERE TO FIND THE TOOLS
-----------------------
  Navisworks ribbon > Tool Add-ins tab:
    - Faruk ClashReport 6000inator
    - Group Existing Clashes
    - Clash Status Export
    - Clash Status Import
  No Tool Add-ins tab? Right-click the ribbon > Show Tabs > Tool Add-ins.
  Hover over a button to see what it does.


UNINSTALL
---------
  Windows Settings > Apps > Installed apps > Faruk BIM Tools > Uninstall
  (or Start menu > Faruk BIM Tools > Uninstall Faruk BIM Tools).
  Close Navisworks first. Your reports, exports and models are not touched.


TROUBLESHOOTING
---------------
  Buttons are missing
    - Restart Navisworks after installing.
    - Check that you are using Navisworks MANAGE 2023, 2025 or 2026 and
      that you ticked that version during setup. To add a version, run the
      setup again.
  "Plugin already loaded" or two identical buttons
    - An older copy of a tool is still installed elsewhere. Setup offers
      to switch old copies off; run it again and answer Yes.
  The 6000inator shows "PICTURES PAUSED"
    - Save, close and reopen Navisworks, then run it again with the same
      choices and the same file name. Finished pictures are kept.


TERMS, PRIVACY, CONTACT
-----------------------
  - Use is governed by TERMS_OF_USE.txt. Provided AS IS, without warranty.
  - The tools run only on your PC. No internet, nothing is sent anywhere.
  - Third-party notices: THIRD_PARTY_NOTICES.txt
  - Autodesk, Navisworks, Revit and Dynamo are trademarks of Autodesk, Inc.
    These tools are not affiliated with or endorsed by Autodesk.
  - Contact: Faruk Ajanovic - ajanovic.faruk@gmail.com
